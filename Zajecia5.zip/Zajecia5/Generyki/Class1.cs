﻿namespace Generyki
{
    public class Student :IComparable<Student>
    {
        private string nazwisko;
        private double ocena;
        public string Nazwisko
        {
            get; set;
        }
        public double Ocena
        { get; set; }
        public int CompareTo(Student s)
        {
            return this.Ocena.CompareTo(s.Ocena);
        }
        public override string ToString()
        {
            return $"Student: {nazwisko}, ocena: {ocena}";
        }
    }

    public static class KlasaZMetodaGeneryczna
    {
        public static T ZnajdzWiekszy<T>(ref T x, ref T y) where T:IComparable<T>
        {
            if (x.CompareTo(y)>=0) return x;
            else return y;
            
        }
    }
}