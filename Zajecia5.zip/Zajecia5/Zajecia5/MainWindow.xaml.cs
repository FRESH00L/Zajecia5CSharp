﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Generyki;

namespace Zajecia5
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        
        private void btn_Click(object sender, RoutedEventArgs e)
        {
            Stozek stozek = new Stozek();
            stozek.obslugaBledu += bladMessageBox;
            stozek.obslugaBledu += bladLabel;

            stozek.Wysokosc = Convert.ToDouble(tb_Wysokosc.Text);
            stozek.Promien = Convert.ToDouble(tb_Promien.Text);
        }
        public void bladMessageBox(string info)
        {
            MessageBox.Show(info);
        }
        public void bladLabel(string info)
        {
            lbl_error.Content = $"Błąd: {info}";
        }

        private void btn_Compare_Click(object sender, RoutedEventArgs e)
        {
            string s1 = "Ala";
            string s2 = "Ola";
            string s = KlasaZMetodaGeneryczna.ZnajdzWiekszy(ref s1, ref s2);
            lbl_string.Content = s;

            double d1 = 3.5;
            double d2 = 6.5;
            double d = KlasaZMetodaGeneryczna.ZnajdzWiekszy(ref d1, ref d2);
            lbl_double.Content = d;

            Student st1 = new Student();
            st1.Nazwisko = "Kowalski";
            st1.Ocena = 5.0;
            Student st2 = new Student();
            st2.Nazwisko = "Boryna";
            st2.Ocena = 4.5;
            Student st = KlasaZMetodaGeneryczna.ZnajdzWiekszy(ref st1, ref st2);
            lbl_student.Content = st;
            
            

        }
    }
}
