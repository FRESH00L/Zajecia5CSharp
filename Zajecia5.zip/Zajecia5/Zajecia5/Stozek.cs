﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Zajecia5
{
    internal class Stozek
    {
        private double wysokosc;
        private double promien;
        public delegate void ObslugaBledu(string info);
        public event ObslugaBledu obslugaBledu;
        public double Wysokosc
        { 
            get { return wysokosc; }
            set {
                if (value > 0)
                    wysokosc = value;
                else
                {
                    obslugaBledu?.Invoke("Niepoprawne dane");
                }
            }
        }
        public double Promien
        { get { return promien; } set { wysokosc = value; } }

        
    }
}
